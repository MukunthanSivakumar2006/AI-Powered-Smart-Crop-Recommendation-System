# Now let's test the training with the fixed dataset
print("🧪 TESTING TRAINING WITH FIXED DATASET")
print("="*50)

# Run the training script
exec(open('train_model.py').read())