# Recreate and run the training script directly
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import pickle
import os
import warnings
warnings.filterwarnings('ignore')

print("🌾 CROP RECOMMENDATION SYSTEM - TRAINING")
print("="*50)

# Load the dataset
try:
    df = pd.read_csv('Crop_recommendation.csv')
    print(f"✅ Dataset loaded successfully!")
    print(f"Dataset shape: {df.shape}")
    print(f"Unique crops: {len(df['label'].unique())}")
    print(f"Crop types: {list(df['label'].unique()[:10])}...")  # Show first 10
except Exception as e:
    print(f"❌ Error loading dataset: {e}")
    exit()

# Check for missing values
missing_values = df.isnull().sum().sum()
if missing_values > 0:
    print(f"⚠️  Warning: {missing_values} missing values found")
    df = df.dropna()

print("\n🔄 Preprocessing data...")

# Encode labels
label_encoder = LabelEncoder()
df['label_encoded'] = label_encoder.fit_transform(df['label'])
print(f"✓ Label encoding completed. Classes: {len(label_encoder.classes_)} crops")

# Prepare features and target
feature_columns = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
X = df[feature_columns]
y = df['label_encoded']

# Scale features
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)
print("✓ Feature scaling completed")

print("\n🤖 Training models...")

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)
print(f"Training set: {X_train.shape[0]} samples")
print(f"Testing set: {X_test.shape[0]} samples")

# Define models
models = {
    'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000),
    'Random Forest': RandomForestClassifier(random_state=42, n_estimators=100),
    'Gradient Boosting': GradientBoostingClassifier(random_state=42, n_estimators=100)
}

best_model = None
best_accuracy = 0
best_model_name = ""

# Train and evaluate each model
for name, model in models.items():
    print(f"\n--- Training {name} ---")
    
    # Train model
    model.fit(X_train, y_train)
    
    # Make predictions
    y_pred = model.predict(X_test)
    
    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy:.4f}")
    
    # Store best model
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_model = model
        best_model_name = name
    
    # Show sample of classification report for space
    if accuracy > 0.8:  # Only show for good models
        print("Sample metrics (first 5 crops):")
        report = classification_report(y_test, y_pred, target_names=label_encoder.classes_, 
                                     zero_division=0, output_dict=True)
        for i, crop in enumerate(list(label_encoder.classes_)[:5]):
            if crop in report:
                precision = report[crop]['precision']
                recall = report[crop]['recall']
                f1 = report[crop]['f1-score']
                print(f"  {crop}: P={precision:.3f}, R={recall:.3f}, F1={f1:.3f}")

print(f"\n🏆 Best model: {best_model_name} with accuracy: {best_accuracy:.4f}")

# Create models directory if it doesn't exist
if not os.path.exists('models'):
    os.makedirs('models')

print("\n💾 Saving model components...")

# Save components
with open('models/encoder.pkl', 'wb') as f:
    pickle.dump(label_encoder, f)

with open('models/scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

with open('models/model.pkl', 'wb') as f:
    pickle.dump(best_model, f)

print("✅ Model components saved successfully!")

# Test prediction function
print("\n🧪 Testing prediction function...")

def predict_crop(N, P, K, temperature, humidity, ph, rainfall):
    """Predict crop based on input parameters"""
    # Load components
    with open('models/encoder.pkl', 'rb') as f:
        encoder = pickle.load(f)
    with open('models/scaler.pkl', 'rb') as f:
        scaler = pickle.load(f)
    with open('models/model.pkl', 'rb') as f:
        model = pickle.load(f)
    
    # Create input dataframe
    input_data = pd.DataFrame({
        'N': [N], 'P': [P], 'K': [K],
        'temperature': [temperature], 'humidity': [humidity],
        'ph': [ph], 'rainfall': [rainfall]
    })
    
    # Scale input
    input_scaled = scaler.transform(input_data)
    
    # Predict
    prediction = model.predict(input_scaled)
    crop_name = encoder.inverse_transform(prediction)[0]
    
    return crop_name

# Test with different scenarios
test_cases = [
    (90, 42, 43, 20.88, 82.00, 6.50, 202.94),  # Rice conditions
    (80, 45, 20, 25.0, 70.0, 6.5, 80.0),      # Maize conditions
    (25, 70, 80, 18.0, 16.0, 7.0, 75.0),      # Chickpea conditions
    (10, 130, 200, 22.0, 92.0, 6.5, 110.0),   # Apple conditions
]

for i, (N, P, K, temp, hum, ph, rain) in enumerate(test_cases):
    predicted_crop = predict_crop(N, P, K, temp, hum, ph, rain)
    print(f"Test {i+1}: N={N}, P={P}, K={K}, T={temp}°C, H={hum}%, pH={ph}, R={rain}mm")
    print(f"Predicted crop: {predicted_crop}")

print("\n" + "="*50)
print("✅ TRAINING COMPLETED SUCCESSFULLY!")
print("✅ All bugs have been fixed!")
print("="*50)
print("\n🚀 Next steps:")
print("1. Run the Streamlit app: streamlit run app.py")
print("2. Use the web interface to get crop recommendations")