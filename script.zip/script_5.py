# Create a comprehensive dataset with multiple crops based on the attachment
# I'll create samples for different crops to demonstrate the system
import pandas as pd
import numpy as np

# Create dataset with multiple crop types
np.random.seed(42)

# Define crop types and their typical characteristics
crops_data = {
    'rice': {'N': (60, 100), 'P': (35, 60), 'K': (35, 45), 'temp': (20, 27), 'humidity': (75, 85), 'ph': (5, 8), 'rainfall': (180, 300)},
    'maize': {'N': (60, 100), 'P': (35, 60), 'K': (15, 25), 'temp': (18, 27), 'humidity': (55, 75), 'ph': (5.5, 7), 'rainfall': (60, 110)},
    'wheat': {'N': (70, 120), 'P': (40, 80), 'K': (30, 50), 'temp': (15, 25), 'humidity': (60, 80), 'ph': (6, 7.5), 'rainfall': (150, 250)},
    'cotton': {'N': (100, 140), 'P': (35, 60), 'K': (15, 25), 'temp': (22, 26), 'humidity': (75, 85), 'ph': (5.5, 8), 'rainfall': (60, 100)},
    'banana': {'N': (80, 120), 'P': (70, 95), 'K': (45, 55), 'temp': (25, 30), 'humidity': (75, 85), 'ph': (5.5, 7), 'rainfall': (90, 120)},
    'apple': {'N': (0, 40), 'P': (120, 145), 'K': (195, 205), 'temp': (21, 24), 'humidity': (90, 95), 'ph': (5.5, 7), 'rainfall': (100, 125)},
    'grapes': {'N': (0, 40), 'P': (120, 145), 'K': (195, 205), 'temp': (8, 42), 'humidity': (80, 85), 'ph': (5.5, 7), 'rainfall': (65, 75)},
    'orange': {'N': (0, 40), 'P': (5, 30), 'K': (5, 15), 'temp': (10, 35), 'humidity': (90, 95), 'ph': (6, 8), 'rainfall': (100, 120)},
    'chickpea': {'N': (20, 60), 'P': (55, 80), 'K': (75, 85), 'temp': (17, 21), 'humidity': (14, 20), 'ph': (6, 9), 'rainfall': (65, 95)},
    'kidneybeans': {'N': (0, 40), 'P': (55, 80), 'K': (15, 25), 'temp': (15, 25), 'humidity': (18, 25), 'ph': (5.5, 6), 'rainfall': (60, 150)},
}

# Generate synthetic dataset
all_data = []
samples_per_crop = 100

for crop, ranges in crops_data.items():
    for _ in range(samples_per_crop):
        sample = {
            'N': np.random.uniform(ranges['N'][0], ranges['N'][1]),
            'P': np.random.uniform(ranges['P'][0], ranges['P'][1]),
            'K': np.random.uniform(ranges['K'][0], ranges['K'][1]),
            'temperature': np.random.uniform(ranges['temp'][0], ranges['temp'][1]),
            'humidity': np.random.uniform(ranges['humidity'][0], ranges['humidity'][1]),
            'ph': np.random.uniform(ranges['ph'][0], ranges['ph'][1]),
            'rainfall': np.random.uniform(ranges['rainfall'][0], ranges['rainfall'][1]),
            'label': crop
        }
        all_data.append(sample)

# Create DataFrame
df = pd.DataFrame(all_data)

# Round numerical values for better readability
df['N'] = df['N'].round().astype(int)
df['P'] = df['P'].round().astype(int)
df['K'] = df['K'].round().astype(int)
df['temperature'] = df['temperature'].round(2)
df['humidity'] = df['humidity'].round(2)
df['ph'] = df['ph'].round(2)
df['rainfall'] = df['rainfall'].round(2)

# Save to CSV
df.to_csv('Crop_recommendation.csv', index=False)

print(f"Dataset created with shape: {df.shape}")
print(f"\nCrop distribution:")
print(df['label'].value_counts())
print(f"\nDataset info:")
print(df.info())
print(f"\nFirst few rows:")
print(df.head(10))