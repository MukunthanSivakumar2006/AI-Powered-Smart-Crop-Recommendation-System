# Complete Crop Recommendation System - Training Phase
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import pickle
import warnings
warnings.filterwarnings('ignore')

print("=== CROP RECOMMENDATION SYSTEM ===\n")
print("1. Loading and preprocessing data...")

# Load the dataset
df = pd.read_csv('Crop_recommendation.csv')
print(f"Dataset loaded successfully!")
print(f"Dataset shape: {df.shape}")
print(f"Unique crops: {len(df['label'].unique())}")
print(f"Crop types: {list(df['label'].unique())}")

# Check for missing values
print(f"\nMissing values: {df.isnull().sum().sum()}")

# 2. Preprocessing
print("\n2. Data preprocessing...")

# Encode labels
label_encoder = LabelEncoder()
df['label_encoded'] = label_encoder.fit_transform(df['label'])
print(f"Label encoding completed. Classes: {label_encoder.classes_}")

# Prepare features and target
feature_columns = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
X = df[feature_columns]
y = df['label_encoded']

# Scale features
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

print("Feature scaling completed.")

# 3. Train-test split
print("\n3. Splitting data...")
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)
print(f"Training set: {X_train.shape[0]} samples")
print(f"Testing set: {X_test.shape[0]} samples")

# 4. Model training and evaluation
print("\n4. Training and evaluating models...")

models = {
    'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000),
    'Random Forest': RandomForestClassifier(random_state=42, n_estimators=100),
    'Gradient Boosting': GradientBoostingClassifier(random_state=42, n_estimators=100)
}

best_model = None
best_accuracy = 0
best_model_name = ""

for name, model in models.items():
    print(f"\n--- {name} ---")
    
    # Train model
    model.fit(X_train, y_train)
    
    # Make predictions
    y_pred = model.predict(X_test)
    
    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy:.4f}")
    
    # Store best model
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_model = model
        best_model_name = name
    
    # Print classification report
    print("Classification Report:")
    print(classification_report(y_test, y_pred, target_names=label_encoder.classes_, zero_division=0))

print(f"\n5. Best model: {best_model_name} with accuracy: {best_accuracy:.4f}")

# 6. Save the trained components
print("\n6. Saving model components...")

# Create models directory
import os
if not os.path.exists('models'):
    os.makedirs('models')

# Save encoder, scaler, and best model
with open('models/encoder.pkl', 'wb') as f:
    pickle.dump(label_encoder, f)

with open('models/scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

with open('models/model.pkl', 'wb') as f:
    pickle.dump(best_model, f)

print("Model components saved successfully!")
print("Files saved: encoder.pkl, scaler.pkl, model.pkl")

# 7. Test prediction function
print("\n7. Testing prediction function...")

def predict_crop(N, P, K, temperature, humidity, ph, rainfall):
    """
    Predict crop based on soil and environmental conditions
    """
    # Load saved components
    with open('models/encoder.pkl', 'rb') as f:
        encoder = pickle.load(f)
    
    with open('models/scaler.pkl', 'rb') as f:
        scaler = pickle.load(f)
    
    with open('models/model.pkl', 'rb') as f:
        model = pickle.load(f)
    
    # Create input dataframe
    input_data = pd.DataFrame({
        'N': [N],
        'P': [P],
        'K': [K], 
        'temperature': [temperature],
        'humidity': [humidity],
        'ph': [ph],
        'rainfall': [rainfall]
    })
    
    # Scale the input
    input_scaled = scaler.transform(input_data)
    
    # Make prediction
    prediction = model.predict(input_scaled)
    
    # Convert back to crop name
    crop_name = encoder.inverse_transform(prediction)[0]
    
    return crop_name

# Test with sample data
test_cases = [
    (90, 42, 43, 20.88, 82.00, 6.50, 202.94),  # Should predict rice
    (80, 45, 20, 25.0, 70.0, 6.5, 80.0),      # Should predict maize
    (25, 70, 80, 18.0, 16.0, 7.0, 75.0),      # Should predict chickpea
    (120, 80, 200, 22.0, 92.0, 6.5, 110.0),   # Should predict apple
]

for i, (N, P, K, temp, hum, ph, rain) in enumerate(test_cases):
    predicted_crop = predict_crop(N, P, K, temp, hum, ph, rain)
    print(f"Test case {i+1}: N={N}, P={P}, K={K}, temp={temp}, humidity={hum}, ph={ph}, rainfall={rain}")
    print(f"Predicted crop: {predicted_crop}\n")

print("✅ Model training and testing completed successfully!")