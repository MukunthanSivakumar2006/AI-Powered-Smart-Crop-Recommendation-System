# Create requirements.txt file
requirements = '''streamlit>=1.28.0
pandas>=1.5.0
numpy>=1.24.0
scikit-learn>=1.3.0
pickle-mixin>=1.0.2
'''

with open('requirements.txt', 'w') as f:
    f.write(requirements)

print("✅ Requirements file created: requirements.txt")